// ============================================================
//  PROJECT 02 — COUNTER APP  (starter file)
//  Follow the Build Guide on the platform step by step.
//  Everything below the state variable is yours to write.
// ============================================================


// ── Already written for you ───────────────────────────────────
// The app's state — one variable that holds the current count.
// We use let (not const) because this value will change.
let count = 0;


// ── Your code goes below ──────────────────────────────────────

// STEP 2 — Grab the count display element (id="count")


// STEP 3 — Grab the three buttons:
//   id="btn-increment"   id="btn-decrement"   id="btn-reset"


// STEP 4 — Write the updateDisplay function
//   Set countEl.textContent to count
//   Remove "positive" and "negative" classes from countEl
//   If count > 0  → add class "positive"
//   If count < 0  → add class "negative"


// STEP 5 — Write the increment function  (count + 1, then updateDisplay)


// STEP 6 — Write the decrement function  (count - 1, then updateDisplay)


// STEP 7 — Write the reset function      (count = 0, then updateDisplay)


// STEP 8 — Attach each function to its button's "click" event


// STEP 9 — Call updateDisplay() once now so the page starts in sync
