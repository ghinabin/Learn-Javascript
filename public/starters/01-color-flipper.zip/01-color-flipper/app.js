// ============================================================
//  PROJECT 01 — COLOR FLIPPER  (starter file)
//  Follow the Build Guide on the platform step by step.
//  Everything below the colors array is yours to write.
// ============================================================


// ── Already written for you ───────────────────────────────────
// An array of 12 hex color strings.
// colors[0] === "#e74c3c"   colors.length === 12
const colors = [
  "#e74c3c", "#3498db", "#2ecc71", "#f39c12",
  "#9b59b6", "#1abc9c", "#e67e22", "#e91e63",
  "#00bcd4", "#8bc34a", "#ff5722", "#607d8b",
];


// ── Your code goes below ──────────────────────────────────────

// STEP 2 — Grab the button from the HTML (id="btn")


// STEP 3 — Grab the color display element (id="color-code")


// STEP 5 — Write the changeColor function
//   Inside it:
//   STEP 6 — pick a random index from the colors array
//   STEP 7 — get the color at that index
//   STEP 8 — set document.body.style.backgroundColor to the color
//   STEP 9 — set colorCode.textContent to the color


// STEP 10 — Attach changeColor to the button's "click" event
